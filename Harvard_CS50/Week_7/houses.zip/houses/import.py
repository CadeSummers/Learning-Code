#Program that provides house rosters based on Hogwarts from Harry Potter

#import modules csv and cs50
import cs50, csv

#import commands argv & exit
from sys import argv, exit

#ensure number of arguments on command line is 2
if len(argv) != 2:
    print("Improper number of arguments. Usage: python houses.py (.csv file). Try again.")
    exit(1)
    
#ensure that argv 1 is a csv
if argv[1].endswith(".csv") == False:
    print("Invalid file type. Please use a .csv file. Try again.")
    exit(2)

#create a variable named db using sqlite3
db = cs50.SQL("sqlite:///students.db")

#open the 2nd argument (the csv file) as charfile
with open(argv[1], "r") as charfile:
    
    #create a variable called reader that reads from the charfile
    reader = csv.reader(charfile)
    
    #iterate over each line of the charfile as reader using a for loop iterating via a variable called row
    for row in reader:
        
        #skip the the first row, which is just the name category
        if row[0] == 'name':
            continue
        
        else:
            
            #create a variable called fullname to store all the seperate names of a character
            fullname = row[0].split(" ")
            
            #if the len of fullname is 2, only 2 names are stored, and set the variables fname and lname equal to them
            if len(fullname) == 2:
                fname = fullname[0]
                lname = fullname[1]
                
                #after initializing name variables, set house and birth variables equivalent to row data at respective columns
                house = row[1]
                birth = row[2]
                
                #insert into the student table in the students database the name of the student
                db.execute("INSERT INTO students (first, last, house, birth) VALUES(?, ?, ?, ?)", fname, lname, house, birth)
                
            #if the len of fullname is 3, character has a middle name, and set the second indexed name to be mname and the last indexed name to be lname
            elif len(fullname) == 3:
                fname = fullname[0]
                mname = fullname[1]
                lname = fullname[2]
                
                #after initializing name variables, set house and birth variables equivalent to row data at respective columns
                house = row[1]
                birth = row[2]
             
                #insert into the student table in the students database the name of the student
                db.execute("INSERT INTO students (first, middle, last, house, birth) VALUES(?, ?, ?, ?, ?)", fname, mname, lname, house, birth)
