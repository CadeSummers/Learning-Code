//program to illustrate looping in javascript

for (let i = 0; i < 10; i++)
{
    console.log(i)
}