// to initialize a variable to some number, you use the "let" keyword
 
let counter = 0;

counter++;

//console.log is the print statement in javascript
console.log(counter);