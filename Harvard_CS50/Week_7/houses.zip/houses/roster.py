#program that takes the name of a house and returns all students in that house

#import the cs50 module
import cs50

#import commands argv & exit
from sys import argv, exit

#ensure number of arguments on command line is 2
if len(argv) != 2:
    print("Improper number of arguments. Usage: python houses.py (.csv file). Try again.")
    exit(1)

#create list containing valid houses    
valid_houses = ["Ravenclaw", "Slytherin", "Gryffindor", "Hufflepuff"]    
    
#ensure that argv 1 is a valid house
if argv[1] not in valid_houses:
    print("Invalid file type. Please use a .csv file. Try again.")
    exit(2)

#open students.db in read mode
#open("students.db", "r")

#create a variable called db equivalent to the students.db database
db = cs50.SQL("sqlite:///students.db")

#select all of the students where the house is equivalent to the argument value, order the list by ascending (a-z) names (first ordering it by first names, then by last names for final organization to be last-name dominate), and save it as a variable named house_students
house_students = db.execute('SELECT * from students WHERE house = ? ORDER BY first ASC LIMIT 40', argv[1])
house_students = db.execute('SELECT * from students WHERE house = ? ORDER BY last ASC LIMIT 40', argv[1])

#print each student in the list of house students
for student in house_students:
    #if student has no middle name, print excluding middle name column
    if str(student['middle']) == 'None':
        print(student['first'] + ' ' + student['last'] + ', born ' + str(student['birth']))
    #if the student has a middle name, include it as well
    else:
        print(student['first'] + ' ' + str(student['middle']) + ' ' + student['last'] + ', born ' + str(student['birth']))

