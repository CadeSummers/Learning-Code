x = "hi"

y = "david"

print(f"{x} {y}")